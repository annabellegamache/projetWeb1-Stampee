-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 22 sep. 2022 à 15:05
-- Version du serveur :  10.3.36-MariaDB-0+deb10u1
-- Version de PHP : 7.3.31-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e0239070`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `cat_id` int(11) NOT NULL,
  `cat_nom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `enchere`
--

CREATE TABLE `enchere` (
  `enc_id` int(11) NOT NULL,
  `enc_nom` varchar(100) NOT NULL,
  `enc_type` varchar(100) DEFAULT NULL,
  `enc_date_debut` datetime NOT NULL,
  `enc_date_fin` datetime DEFAULT NULL,
  `enc_prix_reserve` float NOT NULL,
  `enc_prix_depart` float NOT NULL,
  `enc_prix` float DEFAULT NULL,
  `enc_cat_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

CREATE TABLE `etudiants` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`id`, `nom`, `age`) VALUES
(1, 'Annabelle', 41),
(2, 'Denis', 61),
(3, 'Moko', 40),
(4, 'Mahée', 12),
(5, 'test', 52);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `img_id` int(11) NOT NULL,
  `img_nom` varchar(100) NOT NULL,
  `img_chemin` varchar(255) NOT NULL,
  `tim_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `rol_id` int(11) NOT NULL,
  `rol_nom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`rol_id`, `rol_nom`) VALUES
(0, 'admin'),
(1, 'membre');

-- --------------------------------------------------------

--
-- Structure de la table `timbre`
--

CREATE TABLE `timbre` (
  `tim_id` int(11) NOT NULL,
  `tim_nom` varchar(100) NOT NULL,
  `tim_description` longtext NOT NULL,
  `tim_date_creation` date NOT NULL,
  `tim_pays` varchar(100) NOT NULL,
  `tim_couleur` varchar(100) NOT NULL,
  `tim_condition` set('Entièrement neuf','Comme neuf','Très bon','Bon Acceptable') NOT NULL,
  `tim_tirage` varchar(100) DEFAULT NULL,
  `tim_dimension` varchar(100) DEFAULT NULL,
  `tim_certifie` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tim_appartient_enc`
--

CREATE TABLE `tim_appartient_enc` (
  `tim_appartient_enc_id` int(11) NOT NULL,
  `tim_id_ce` int(11) NOT NULL,
  `enc_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `uti_id` int(11) NOT NULL,
  `uti_courriel` varchar(100) NOT NULL,
  `uti_mdp` varchar(100) NOT NULL,
  `uti_prenom` varchar(100) NOT NULL,
  `uti_nom` varchar(100) NOT NULL,
  `uti_status` tinyint(4) NOT NULL,
  `uti_rol_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`uti_id`, `uti_courriel`, `uti_mdp`, `uti_prenom`, `uti_nom`, `uti_status`, `uti_rol_id_ce`) VALUES
(2, 'admin@admin.com', '$2y$10$HEtV4MqMgsuJvIDRwMNXGuvS6sLH7T5BAhElQbFrQXJFbnbS6YxN6', 'admin', 'admin', 1, 0),
(3, 'test@test.com', '$2y$10$WCjFUfY0EsUc/SsnA43Ns.UA2gM7DK7hP9hehEsRpnYQkEZLFraKC', 'test', 'test', 1, 1),
(4, 'annabellegamache@gmail.com', '$2y$10$jfNbe.TImU2p3XuZq3HGLuY/mThCnXdMKDuC02uKU4/wSGISG.Pxm', 'Annabelle', 'Gamache', 1, 1),
(9, 'testggg@gdsdgs.com', '$2y$10$PDp8MlpHuevZkKJmJN18mOtWBeKKZh6ce8oojv4N2AudDyC5iGj2e', 'testeee', 'testsete', 1, 1),
(10, 'agama@adsfa.com', '$2y$10$OuFTVHh0UmsRpjznxCO7aeAXCsV3oCrAE4R3ttbrmCoikUL0qJX1y', 'sffdd', 'sdfgsdfdf', 1, 1),
(11, 'agamache@adfs.com', '$2y$10$WCtwJGRPLQz4VB37hWU/We2/KSoNW2uD4q6jVBwJAOqr9m8LwY/xC', 'sfgf', 'sdfgsdf', 1, 1),
(13, 'asdfadf@asdfad.com', '$2y$10$QQAeHKs/sNqSlCYGsOYOpO.WKpUFLrUVRQ5SDStC69qTidkSrAu5m', 'dsafsafasdfasdf', 'asdfasdfasdfa', 1, 1),
(14, 'sfgsdfgsd@adsf.com', '$2y$10$6jw/sY5XkpZzWLgmZ9Sf9.h3rrBCcuQAm9kcOO2osSkBN4aPX0U9O', 'thgdjfuyd', 'fghfdfhd', 1, 1),
(15, 'asfdas@afdsda.com', '$2y$10$dZYVvwe1e4tuJY2vMaGJ1.VMLcHwBmZqKeYsrYYnW3iH1hkDBXsk6', 'reerafdshk', 'safdasfd', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `uti_favori_enc`
--

CREATE TABLE `uti_favori_enc` (
  `uti_favori_enc_id` int(11) NOT NULL,
  `uti_id_ce` int(11) NOT NULL,
  `enc_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `uti_mise_enc`
--

CREATE TABLE `uti_mise_enc` (
  `uti_enc_id` int(11) NOT NULL,
  `uti_id_ce` int(11) NOT NULL,
  `enc_id_ce` int(11) NOT NULL,
  `uti_enc_prix` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `uti_publie_enc`
--

CREATE TABLE `uti_publie_enc` (
  `uti_publie_enc_id` int(11) NOT NULL,
  `uti_id_ce` int(11) NOT NULL,
  `enc_id_ce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`cat_id`);

--
-- Index pour la table `enchere`
--
ALTER TABLE `enchere`
  ADD PRIMARY KEY (`enc_id`),
  ADD KEY `fk_enchere_categorie1_idx` (`enc_cat_id_ce`);

--
-- Index pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`img_id`),
  ADD KEY `fk_image_timbre1_idx` (`tim_id_ce`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`rol_id`);

--
-- Index pour la table `timbre`
--
ALTER TABLE `timbre`
  ADD PRIMARY KEY (`tim_id`);

--
-- Index pour la table `tim_appartient_enc`
--
ALTER TABLE `tim_appartient_enc`
  ADD PRIMARY KEY (`tim_appartient_enc_id`),
  ADD KEY `fk_timbre_has_enchere_enchere1_idx` (`enc_id_ce`),
  ADD KEY `fk_timbre_has_enchere_timbre1_idx` (`tim_id_ce`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`uti_id`),
  ADD UNIQUE KEY `uti_id_UNIQUE` (`uti_id`),
  ADD UNIQUE KEY `uti_courriel_UNIQUE` (`uti_courriel`),
  ADD UNIQUE KEY `uti_mdp_UNIQUE` (`uti_mdp`),
  ADD KEY `fk_utilisateur_role1_idx` (`uti_rol_id_ce`);

--
-- Index pour la table `uti_favori_enc`
--
ALTER TABLE `uti_favori_enc`
  ADD PRIMARY KEY (`uti_favori_enc_id`),
  ADD KEY `fk_utilisateur_has_enchere_enchere3_idx` (`enc_id_ce`),
  ADD KEY `fk_utilisateur_has_enchere_utilisateur3_idx` (`uti_id_ce`);

--
-- Index pour la table `uti_mise_enc`
--
ALTER TABLE `uti_mise_enc`
  ADD PRIMARY KEY (`uti_enc_id`),
  ADD KEY `fk_utilisateur_has_enchere_enchere1_idx` (`enc_id_ce`),
  ADD KEY `fk_utilisateur_has_enchere_utilisateur1_idx` (`uti_id_ce`);

--
-- Index pour la table `uti_publie_enc`
--
ALTER TABLE `uti_publie_enc`
  ADD PRIMARY KEY (`uti_publie_enc_id`),
  ADD KEY `fk_utilisateur_has_enchere_enchere2_idx` (`enc_id_ce`),
  ADD KEY `fk_utilisateur_has_enchere_utilisateur2_idx` (`uti_id_ce`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `etudiants`
--
ALTER TABLE `etudiants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `uti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `enchere`
--
ALTER TABLE `enchere`
  ADD CONSTRAINT `fk_enchere_categorie1` FOREIGN KEY (`enc_cat_id_ce`) REFERENCES `categorie` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `fk_image_timbre1` FOREIGN KEY (`tim_id_ce`) REFERENCES `timbre` (`tim_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `tim_appartient_enc`
--
ALTER TABLE `tim_appartient_enc`
  ADD CONSTRAINT `fk_timbre_has_enchere_enchere1` FOREIGN KEY (`enc_id_ce`) REFERENCES `enchere` (`enc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_timbre_has_enchere_timbre1` FOREIGN KEY (`tim_id_ce`) REFERENCES `timbre` (`tim_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `fk_utilisateur_role1` FOREIGN KEY (`uti_rol_id_ce`) REFERENCES `role` (`rol_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `uti_favori_enc`
--
ALTER TABLE `uti_favori_enc`
  ADD CONSTRAINT `fk_utilisateur_has_enchere_enchere3` FOREIGN KEY (`enc_id_ce`) REFERENCES `enchere` (`enc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_utilisateur_has_enchere_utilisateur3` FOREIGN KEY (`uti_id_ce`) REFERENCES `utilisateur` (`uti_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `uti_mise_enc`
--
ALTER TABLE `uti_mise_enc`
  ADD CONSTRAINT `fk_utilisateur_has_enchere_enchere1` FOREIGN KEY (`enc_id_ce`) REFERENCES `enchere` (`enc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_utilisateur_has_enchere_utilisateur1` FOREIGN KEY (`uti_id_ce`) REFERENCES `utilisateur` (`uti_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `uti_publie_enc`
--
ALTER TABLE `uti_publie_enc`
  ADD CONSTRAINT `fk_utilisateur_has_enchere_enchere2` FOREIGN KEY (`enc_id_ce`) REFERENCES `enchere` (`enc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_utilisateur_has_enchere_utilisateur2` FOREIGN KEY (`uti_id_ce`) REFERENCES `utilisateur` (`uti_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
